
import folium
import js

def show(carte, cible:str=None):
    """Affiche la carte Folium dans la figure dont l'identifiant est `cible`."""
    cible = cible or js.config().argsFigureDivId
    js.document.getElementById(cible).innerHTML = carte._repr_html_()

folium.show = show